# Complete VPS Installation Guide

## Prerequisites
- Ubuntu/Debian VPS with sudo access
- Node.js 18+ installed

## Installation

1. Clone or upload the project to your VPS
2. Navigate to project directory
3. Run the complete setup:
```bash
chmod +x vps-setup.sh
sudo ./vps-setup.sh
```

This script will:
- Install PostgreSQL database server
- Create database and user accounts
- Configure environment variables
- Install Node.js dependencies
- Set up database tables and sample data
- Configure the application for production

4. Start the application:
```bash
export $(cat .env | xargs) && npm start
```

Your crypto airdrop platform will be available at `http://your-server-ip:5000`

## Login Credentials

After installation, login with:
- **Admin Account**: `admin` / `admin123`
- **Demo Account**: `demo` / `demo123`

## Features Available

- User registration and authentication
- Crypto airdrop listings and management
- Real-time crypto price tracking
- Admin dashboard for content management
- Live chat functionality
- Creator application system
- Mobile-responsive design

## Troubleshooting

If you encounter issues:
- Check PostgreSQL: `sudo systemctl status postgresql`
- Test database: `psql $DATABASE_URL -c "SELECT 1;"`
- View logs: `sudo journalctl -u postgresql`
- Restart services: `sudo systemctl restart postgresql`