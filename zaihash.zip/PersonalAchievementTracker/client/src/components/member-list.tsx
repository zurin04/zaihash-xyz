import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2, Download, Search, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type Member = {
  id: number;
  username: string;
  isAdmin: boolean;
  isCreator: boolean;
  profile_image: string | null;
  created_at: string;
};

export default function MemberList() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  
  const { data: members, isLoading, error } = useQuery<Member[]>({
    queryKey: ["/api/members"],
    retry: false
  });

  // Show toast on error
  React.useEffect(() => {
    if (error) {
      toast({
        title: "Error",
        description: `Failed to load members: ${error.message}`,
        variant: "destructive",
      });
    }
  }, [error, toast]);
  
  const filteredMembers = React.useMemo(() => {
    if (!members) return [];
    return members.filter((member: Member) => 
      member.username.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [members, searchTerm]);
  
  const handleExport = () => {
    // Create a download link for the CSV export
    window.open("/api/members/export", "_blank");
  };

  function getInitials(username: string) {
    return username.substring(0, 2).toUpperCase();
  }
  
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-2xl">Member Management</CardTitle>
            <CardDescription>
              View and manage platform members (Admin Only)
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center my-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            <div className="flex items-center mb-4 gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search members..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm("")}
                    className="absolute right-2 top-2.5"
                  >
                    <X className="h-4 w-4 text-muted-foreground" />
                  </button>
                )}
              </div>
              <Button 
                variant="secondary" 
                className="flex items-center gap-2"
                onClick={handleExport}
              >
                <Download className="h-4 w-4" />
                Export CSV
              </Button>
            </div>
            
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Member</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Joined</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMembers && filteredMembers.length > 0 ? (
                    filteredMembers.map((member: Member) => (
                      <TableRow key={member.id}>
                        <TableCell className="flex items-center gap-2">
                          <Avatar className={member.isCreator ? "border-2 border-yellow-500" : ""}>
                            <AvatarImage src={member.profile_image || ""} />
                            <AvatarFallback>{getInitials(member.username)}</AvatarFallback>
                          </Avatar>
                          <span className={member.isCreator ? "text-yellow-500 font-medium" : ""}>
                            {member.username}
                          </span>
                        </TableCell>
                        <TableCell>
                          {member.isAdmin 
                            ? "Admin" 
                            : member.isCreator 
                              ? "Creator" 
                              : "Member"}
                        </TableCell>
                        <TableCell>
                          {new Date(member.created_at).toLocaleDateString()}
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={3} className="text-center py-4">
                        {searchTerm
                          ? "No members found matching your search"
                          : "No members found"}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
            
            <div className="mt-4 text-sm text-muted-foreground">
              Total members: {members?.length || 0}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}