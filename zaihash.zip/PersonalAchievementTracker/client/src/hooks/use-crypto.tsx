import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

interface CryptoPrice {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  market_cap: number;
  market_cap_rank: number;
  price_change_percentage_24h: number;
}

export function useCrypto() {
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  
  const {
    data: coins = [],
    isLoading,
    error,
    refetch
  } = useQuery<CryptoPrice[]>({
    queryKey: ['/api/crypto/prices'],
    onSuccess: () => {
      setLastUpdated(new Date());
    }
  });

  const refetchCoins = async () => {
    await refetch();
  };

  return {
    coins,
    isLoading,
    error,
    refetchCoins,
    lastUpdated,
  };
}
