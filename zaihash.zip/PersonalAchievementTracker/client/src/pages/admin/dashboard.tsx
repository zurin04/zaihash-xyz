import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";
import CategoryManagement from "@/components/admin/category-management";
import SiteSettings from "@/components/admin/site-settings";
import AirdropManagement from "@/components/admin/airdrop-management";
import UserManagement from "@/components/admin/user-management";
import NewsletterManagement from "@/components/admin/newsletter-management";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Settings, Layers, ListChecks, Users, MailIcon } from "lucide-react";
import { Redirect } from "wouter";

function AdminDashboard() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("airdrops");
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!user) {
    return <Redirect to="/auth" />;
  }
  
  if (!user.isAdmin) {
    return (
      <div className="container max-w-4xl mx-auto py-16 px-4">
        <Card>
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>
              You do not have permission to access the admin dashboard.
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={() => window.location.href = "/"}>
              Return to Home
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="container max-w-6xl mx-auto py-8 px-4">
      <Helmet>
        <title>Admin Dashboard - Crypto Airdrop Task Hub</title>
      </Helmet>
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage your site content and settings</p>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-5 mb-8">
          <TabsTrigger value="airdrops" className="flex items-center">
            <ListChecks className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Airdrops</span>
          </TabsTrigger>
          <TabsTrigger value="categories" className="flex items-center">
            <Layers className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Categories</span>
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center">
            <Users className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Users</span>
          </TabsTrigger>
          <TabsTrigger value="newsletter" className="flex items-center">
            <MailIcon className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Newsletter</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center">
            <Settings className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Site Settings</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="airdrops" className="space-y-4">
          <AirdropManagement />
        </TabsContent>
        
        <TabsContent value="categories" className="space-y-4">
          <CategoryManagement />
        </TabsContent>
        
        <TabsContent value="users" className="space-y-4">
          <UserManagement />
        </TabsContent>
        
        <TabsContent value="newsletter" className="space-y-4">
          <NewsletterManagement />
        </TabsContent>
        
        <TabsContent value="settings" className="space-y-4">
          <SiteSettings />
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function AdminDashboardPage() {
  return <AdminDashboard />;
}