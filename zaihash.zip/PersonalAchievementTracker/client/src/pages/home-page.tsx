import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import MainLayout from "@/components/layout/main-layout";
import HeroSection from "@/components/ui/hero-section";
import CryptoTracker from "@/components/crypto/crypto-tracker";
import AirdropList from "@/components/airdrops/airdrop-list";
import ChatRoom from "@/components/chat/chat-room";
import NewsletterSignup from "@/components/newsletter-signup";
import ParticleBackground from "@/components/ui/particle-background";
import Footer from "@/components/layout/footer";
import { Airdrops } from "@shared/schema";
import { motion } from "framer-motion";

export default function HomePage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  
  const { data: airdrops = [] } = useQuery<Airdrops[]>({
    queryKey: ["/api/airdrops/featured"],
  });
  
  // Filter airdrops based on search and tags
  const filteredAirdrops = airdrops.filter((airdrop) => {
    const matchesSearch = !searchTerm || 
      airdrop.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      airdrop.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesTag = !selectedTag || 
      (airdrop.tags && airdrop.tags.includes(selectedTag));
    
    return matchesSearch && matchesTag;
  });

  const sectionVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.6 }
    }
  };

  return (
    <MainLayout title="Your Ultimate Crypto Airdrop Platform">
      <div className="relative">
        {/* Particle Background */}
        <ParticleBackground />
        
        <div className="relative z-10">
          <HeroSection />
          
          {/* Top Coins Section */}
          <motion.section 
            className="p-6 md:p-10"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            variants={sectionVariants}
          >
            <div className="max-w-6xl mx-auto">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl md:text-3xl font-bold text-white flex items-center">
                  <span className="bg-blue-600 w-10 h-10 rounded-full flex items-center justify-center mr-3 shadow-lg shadow-blue-600/20">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                  </span>
                  Top Coins
                </h2>
                <div className="text-sm text-gray-400 flex items-center">
                  <div className="flex items-center bg-card/50 backdrop-blur-sm px-3 py-1 rounded-full">
                    <div className="h-2 w-2 rounded-full bg-green-500 mr-2 animate-pulse"></div>
                    <span id="last-updated">Updated just now</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 p-6 rounded-2xl backdrop-blur-sm border border-gray-800/50 shadow-xl">
                <CryptoTracker />
              </div>
              
              <div className="mt-4 text-center">
                <a href="#" className="inline-flex items-center bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 py-2 px-4 rounded-full text-sm font-medium transition-all duration-300">
                  View all coins 
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </a>
              </div>
            </div>
          </motion.section>
          
          {/* Featured Airdrops Section */}
          <motion.section 
            className="p-6 md:p-10 mx-6 md:mx-10 bg-gradient-to-br from-gray-900/90 to-gray-800/80 backdrop-blur-sm rounded-2xl border border-gray-800/50 shadow-2xl"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.1 }}
            variants={sectionVariants}
          >
            <div className="max-w-6xl mx-auto">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
                <h2 className="text-2xl md:text-3xl font-bold text-white mb-4 sm:mb-0 flex items-center">
                  <span className="bg-purple-600 w-10 h-10 rounded-full flex items-center justify-center mr-3 shadow-lg shadow-purple-600/20">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" />
                    </svg>
                  </span>
                  Featured Airdrops
                </h2>
                <div className="flex space-x-3 w-full sm:w-auto">
                  <div className="relative flex-1 sm:flex-auto">
                    <input 
                      type="text" 
                      placeholder="Search airdrops..." 
                      className="bg-gray-800/50 border border-gray-700 rounded-lg pl-10 pr-4 py-2 text-sm w-full focus:outline-none focus:ring-2 focus:ring-purple-500/50 text-white"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                  </div>
                  <button className="p-2 rounded-lg bg-gray-800/80 hover:bg-gray-700/80 text-gray-400 transition-colors duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                    </svg>
                  </button>
                </div>
              </div>
              
              <AirdropList airdrops={filteredAirdrops} />
              
              <div className="mt-10 text-center">
                <a 
                  href="/airdrops"
                  className="inline-block bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white py-3 px-8 rounded-full font-medium transition-all duration-300 shadow-lg hover:shadow-purple-500/20"
                >
                  View All Airdrops 
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </a>
              </div>
            </div>
          </motion.section>
          
          {/* How It Works Section */}
          <motion.section 
            className="p-6 md:p-10"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.1 }}
            variants={sectionVariants}
          >
            <div className="max-w-6xl mx-auto">
              <h2 className="text-2xl md:text-3xl font-bold text-white mb-8 text-center flex flex-col items-center">
                <span className="bg-indigo-600 w-12 h-12 rounded-full flex items-center justify-center mb-4 shadow-lg shadow-indigo-600/20">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </span>
                How AirdropVerse Works
              </h2>
              
              <div className="grid md:grid-cols-3 gap-8 mt-10">
                {/* Step 1 */}
                <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 rounded-2xl backdrop-blur-sm border border-gray-800/50 shadow-xl p-6 relative overflow-hidden group hover:border-indigo-500/30 transition-all duration-300">
                  <div className="absolute top-0 right-0 bg-indigo-600/20 w-24 h-24 rounded-full -mr-12 -mt-12 group-hover:bg-indigo-600/30 transition-all duration-300"></div>
                  <div className="relative">
                    <div className="bg-indigo-600/90 w-12 h-12 rounded-full flex items-center justify-center mb-4 shadow-lg">
                      <span className="text-white font-bold text-lg">1</span>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-3">Discover Airdrops</h3>
                    <p className="text-gray-300">
                      Browse through our extensive collection of verified crypto airdrops across various blockchain networks. Filter by category, requirements, or rewards to find the perfect opportunities.
                    </p>
                  </div>
                </div>
                
                {/* Step 2 */}
                <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 rounded-2xl backdrop-blur-sm border border-gray-800/50 shadow-xl p-6 relative overflow-hidden group hover:border-purple-500/30 transition-all duration-300">
                  <div className="absolute top-0 right-0 bg-purple-600/20 w-24 h-24 rounded-full -mr-12 -mt-12 group-hover:bg-purple-600/30 transition-all duration-300"></div>
                  <div className="relative">
                    <div className="bg-purple-600/90 w-12 h-12 rounded-full flex items-center justify-center mb-4 shadow-lg">
                      <span className="text-white font-bold text-lg">2</span>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-3">Complete Tasks</h3>
                    <p className="text-gray-300">
                      Follow our comprehensive step-by-step guides to complete all required tasks. Each airdrop includes detailed instructions for social media, testnet participation, or other requirements.
                    </p>
                  </div>
                </div>
                
                {/* Step 3 */}
                <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/30 rounded-2xl backdrop-blur-sm border border-gray-800/50 shadow-xl p-6 relative overflow-hidden group hover:border-blue-500/30 transition-all duration-300">
                  <div className="absolute top-0 right-0 bg-blue-600/20 w-24 h-24 rounded-full -mr-12 -mt-12 group-hover:bg-blue-600/30 transition-all duration-300"></div>
                  <div className="relative">
                    <div className="bg-blue-600/90 w-12 h-12 rounded-full flex items-center justify-center mb-4 shadow-lg">
                      <span className="text-white font-bold text-lg">3</span>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-3">Earn Rewards</h3>
                    <p className="text-gray-300">
                      Track your progress and receive notifications when token distributions begin. Mark completed airdrops and maintain a portfolio of all your earned airdrop rewards.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="text-center mt-12">
                <a 
                  href="/airdrops"
                  className="inline-block bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white py-3 px-8 rounded-full font-medium transition-all duration-300 shadow-lg hover:shadow-indigo-500/20"
                >
                  Get Started Now
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </a>
              </div>
            </div>
          </motion.section>
          
          {/* FAQ Section */}
          <motion.section 
            className="p-6 md:p-10 bg-gradient-to-br from-gray-900/70 to-gray-800/50 mx-6 md:mx-10 rounded-2xl backdrop-blur-sm border border-gray-800/50 shadow-xl my-8"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.1 }}
            variants={sectionVariants}
          >
            <div className="max-w-6xl mx-auto">
              <h2 className="text-2xl md:text-3xl font-bold text-white mb-8 text-center">Frequently Asked Questions</h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                {/* FAQ Item 1 */}
                <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl p-6 border border-gray-700/30 hover:border-gray-700/60 transition-all duration-300">
                  <h3 className="text-xl font-semibold text-white mb-3">What are crypto airdrops?</h3>
                  <p className="text-gray-300">Crypto airdrops are a distribution method where cryptocurrency projects send free tokens to wallet addresses to promote awareness or achieve wide distribution of their token.</p>
                </div>
                
                {/* FAQ Item 2 */}
                <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl p-6 border border-gray-700/30 hover:border-gray-700/60 transition-all duration-300">
                  <h3 className="text-xl font-semibold text-white mb-3">How do I qualify for airdrops?</h3>
                  <p className="text-gray-300">Each airdrop has different requirements. Typically, you'll need to connect your wallet, complete specific tasks like joining social media channels, or participate in testnet activities.</p>
                </div>
                
                {/* FAQ Item 3 */}
                <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl p-6 border border-gray-700/30 hover:border-gray-700/60 transition-all duration-300">
                  <h3 className="text-xl font-semibold text-white mb-3">Are airdrops really free?</h3>
                  <p className="text-gray-300">Yes, legitimate airdrops are free, though you may need to pay gas fees for certain blockchain transactions. We never ask for payments to participate in the airdrops listed on our platform.</p>
                </div>
                
                {/* FAQ Item 4 */}
                <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl p-6 border border-gray-700/30 hover:border-gray-700/60 transition-all duration-300">
                  <h3 className="text-xl font-semibold text-white mb-3">How do I stay safe from scams?</h3>
                  <p className="text-gray-300">Never share your private keys or seed phrases. Be cautious of projects asking for funds to participate. We verify all airdrops listed on our platform for legitimacy and security.</p>
                </div>
              </div>
              
              <div className="text-center mt-8">
                <button className="bg-gray-800/50 hover:bg-gray-700/50 text-white py-2 px-6 rounded-full font-medium transition-colors duration-300">
                  More FAQs
                </button>
              </div>
            </div>
          </motion.section>
          
          {/* Newsletter Section with enhanced design */}
          <NewsletterSignup />
          
          <Footer />
        </div>
      </div>
    </MainLayout>
  );
}
