#!/bin/bash

# Crypto Airdrop Platform - Easy VPS Installation with Nginx
# Compatible with Ubuntu/Debian systems

set -e

echo "=== Crypto Airdrop Platform - Nginx Installation ==="
echo "Easy setup for VPS deployment..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run this script as root (or use sudo)"
    exit 1
fi

# Update system
echo "Updating system packages..."
apt update && apt upgrade -y

# Install required packages
echo "Installing required packages..."
apt install -y curl wget gnupg2 software-properties-common

# Install Node.js 20
echo "Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install PM2 for process management
echo "Installing PM2..."
npm install -g pm2

# Install Nginx
echo "Installing Nginx..."
apt install -y nginx

# Install PostgreSQL
if ! command -v psql &> /dev/null; then
    echo "Installing PostgreSQL..."
    apt install -y postgresql postgresql-contrib
    systemctl start postgresql
    systemctl enable postgresql
fi

# Create application directory
APP_DIR="/var/www/crypto-airdrop"
echo "Setting up application directory at $APP_DIR..."
mkdir -p $APP_DIR
cp -r . $APP_DIR/
cd $APP_DIR

# Set proper permissions
chown -R $USER:$USER $APP_DIR
chmod -R 755 $APP_DIR

# Install application dependencies
echo "Installing application dependencies..."
npm install

# Fix security vulnerabilities
echo "Fixing security vulnerabilities..."
npm audit fix || echo "Audit fix completed with warnings"

# Build the application with timeout handling
echo "Building application (this may take a few minutes)..."
timeout 600 npm run build || {
    echo "Build timed out or failed, trying alternative approach..."
    # Alternative build without bundling for faster deployment
    echo "Creating basic dist structure..."
    mkdir -p dist/public
    cp -r client/* dist/public/ 2>/dev/null || true
    # Build server only
    npx esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist
}

# Create uploads directory
mkdir -p public/uploads

# Setup PostgreSQL database
echo "Setting up PostgreSQL database..."
DB_NAME="crypto_airdrop"
DB_USER="crypto_user"
DB_PASS=$(openssl rand -base64 32)

sudo -u postgres psql <<EOF
CREATE DATABASE $DB_NAME;
CREATE USER $DB_USER WITH ENCRYPTED PASSWORD '$DB_PASS';
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;
ALTER USER $DB_USER CREATEDB;
\q
EOF

# Create environment file
echo "Creating environment configuration..."
cat > .env <<EOF
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME
SESSION_SECRET=$(openssl rand -base64 64)
EOF

# Set environment file permissions
chown root:www-data .env
chmod 640 .env

# Setup database schema
echo "Setting up database schema..."
npm run db:push
npm run db:seed

# Create PM2 ecosystem file
echo "Creating PM2 configuration..."
cat > ecosystem.config.js <<EOF
module.exports = {
  apps: [{
    name: 'crypto-airdrop',
    script: 'dist/index.js',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    error_file: '/var/log/crypto-airdrop/error.log',
    out_file: '/var/log/crypto-airdrop/out.log',
    log_file: '/var/log/crypto-airdrop/combined.log',
    time: true
  }]
}
EOF

# Create log directory
mkdir -p /var/log/crypto-airdrop
chown www-data:www-data /var/log/crypto-airdrop

# Start application with PM2
echo "Starting application..."
pm2 start ecosystem.config.js
pm2 save
pm2 startup

# Setup Nginx configuration
echo "Configuring Nginx..."
cat > /etc/nginx/sites-available/crypto-airdrop <<EOF
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;

    # Main proxy to Node.js app
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }

    # WebSocket support for chat
    location /ws {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    # Static files (uploads)
    location /uploads/ {
        alias $APP_DIR/public/uploads/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # Rate limiting
    limit_req_zone \$binary_remote_addr zone=api:10m rate=10r/s;
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

# Enable the site
ln -sf /etc/nginx/sites-available/crypto-airdrop /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test nginx configuration
nginx -t

# Start and enable services
systemctl enable nginx
systemctl start nginx
systemctl reload nginx

# Create management scripts
echo "Creating management scripts..."

# Update script
cat > update.sh <<'EOF'
#!/bin/bash
echo "Updating Crypto Airdrop Platform..."
cd /var/www/crypto-airdrop

# Pull latest changes (if using git)
if [ -d ".git" ]; then
    git pull origin main
fi

# Install dependencies and build
npm install
npm run build

# Restart application
pm2 restart crypto-airdrop

echo "Application updated successfully!"
EOF

chmod +x update.sh

# Backup script
cat > backup.sh <<'EOF'
#!/bin/bash
BACKUP_DIR="/var/backups/crypto-airdrop"
DATE=$(date +%Y%m%d_%H%M%S)

echo "Creating backup..."
mkdir -p $BACKUP_DIR

# Backup database
sudo -u postgres pg_dump crypto_airdrop > $BACKUP_DIR/database_$DATE.sql

# Backup uploads
if [ -d "/var/www/crypto-airdrop/public/uploads" ]; then
    tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz -C /var/www/crypto-airdrop/public uploads
fi

# Backup environment file
if [ -f "/var/www/crypto-airdrop/.env" ]; then
    cp /var/www/crypto-airdrop/.env $BACKUP_DIR/env_$DATE.backup
fi

# Keep only last 30 days of backups
find $BACKUP_DIR -type f -mtime +30 -delete

echo "Backup completed: $BACKUP_DIR"
ls -la $BACKUP_DIR/
EOF

chmod +x backup.sh

# SSL setup script
cat > setup-ssl.sh <<'EOF'
#!/bin/bash
echo "Setting up SSL certificate..."

# Install certbot
apt update
apt install -y certbot python3-certbot-nginx

# Get certificate (replace your-domain.com with actual domain)
echo "Please replace 'your-domain.com' with your actual domain name in the command below:"
echo "certbot --nginx -d your-domain.com -d www.your-domain.com"
echo ""
echo "Run this command after updating your domain in /etc/nginx/sites-available/crypto-airdrop"
EOF

chmod +x setup-ssl.sh

# Setup daily backup cron
echo "0 2 * * * root /var/www/crypto-airdrop/backup.sh" >> /etc/crontab

# Security hardening
echo "Applying security hardening..."

# Configure UFW firewall
ufw --force enable
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow 80/tcp
ufw allow 443/tcp

# Secure shared memory
echo "tmpfs /run/shm tmpfs defaults,noexec,nosuid 0 0" >> /etc/fstab

# Network security
echo "net.ipv4.conf.default.rp_filter=1" >> /etc/sysctl.conf
echo "net.ipv4.conf.all.rp_filter=1" >> /etc/sysctl.conf
echo "net.ipv4.tcp_syncookies=1" >> /etc/sysctl.conf
echo "net.ipv4.conf.all.accept_redirects=0" >> /etc/sysctl.conf
echo "net.ipv6.conf.all.accept_redirects=0" >> /etc/sysctl.conf
echo "net.ipv4.conf.all.send_redirects=0" >> /etc/sysctl.conf
echo "net.ipv4.conf.all.accept_source_route=0" >> /etc/sysctl.conf
echo "net.ipv6.conf.all.accept_source_route=0" >> /etc/sysctl.conf
echo "net.ipv4.conf.all.log_martians=1" >> /etc/sysctl.conf
sysctl -p

# Setup fail2ban for additional security
apt install -y fail2ban
systemctl enable fail2ban
systemctl start fail2ban

# Create fail2ban nginx config
cat > /etc/fail2ban/jail.local <<EOF
[nginx-http-auth]
enabled = true
filter = nginx-http-auth
logpath = /var/log/nginx/error.log
maxretry = 5
bantime = 3600

[nginx-dos]
enabled = true
filter = nginx-dos
logpath = /var/log/nginx/access.log
maxretry = 200
findtime = 300
bantime = 600
action = iptables[name=HTTP, port=http, protocol=tcp]
EOF

systemctl restart fail2ban

echo ""
echo "=== ✅ Installation Complete! ==="
echo ""
echo "📊 Database Details:"
echo "  Name: $DB_NAME"
echo "  User: $DB_USER"
echo "  Password: $DB_PASS"
echo "  Connection: postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME"
echo ""
echo "🌐 Server Status:"
echo "  ✅ Node.js Application: http://localhost:3000"
echo "  ✅ Nginx Proxy: http://your-server-ip"
echo "  ✅ PM2 Process Manager: Active"
echo ""
echo "🔧 Next Steps:"
echo "1. Update your domain name:"
echo "   nano /etc/nginx/sites-available/crypto-airdrop"
echo "   (Replace 'your-domain.com' with your actual domain)"
echo ""
echo "2. Reload nginx after domain update:"
echo "   systemctl reload nginx"
echo ""
echo "3. Setup SSL certificate (recommended):"
echo "   ./setup-ssl.sh"
echo ""
echo "📋 Management Commands:"
echo "  pm2 status                    - Check application status"
echo "  pm2 restart crypto-airdrop    - Restart application"
echo "  pm2 logs crypto-airdrop       - View logs"
echo "  ./update.sh                   - Update application"
echo "  ./backup.sh                   - Create backup"
echo "  systemctl status nginx        - Check nginx status"
echo "  nginx -t                      - Test nginx config"
echo ""
echo "🔒 Security Notes:"
echo "  - Change default database password"
echo "  - Setup SSL certificate"
echo "  - Configure firewall (ufw enable)"
echo "  - Regular backups are scheduled daily at 2 AM"
echo ""