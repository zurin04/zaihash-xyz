#!/bin/bash

# Complete VPS setup script for Crypto Airdrop Platform
set -e

echo "🚀 Setting up Crypto Airdrop Platform on VPS..."

# Install PostgreSQL if not present
if ! command -v psql &> /dev/null; then
    echo "Installing PostgreSQL..."
    sudo apt update
    sudo apt install -y postgresql postgresql-contrib
    sudo systemctl start postgresql
    sudo systemctl enable postgresql
fi

# Database configuration
DB_NAME="crypto_airdrop"
DB_USER="crypto_user"
DB_PASSWORD="crypto_secure_2024"

echo "Configuring database..."

# Reset database and user
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS ${DB_NAME};
DROP USER IF EXISTS ${DB_USER};
CREATE DATABASE ${DB_NAME};
CREATE USER ${DB_USER} WITH ENCRYPTED PASSWORD '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
ALTER USER ${DB_USER} CREATEDB;
ALTER USER ${DB_USER} SUPERUSER;
\q
EOF

# Create environment file
cat > .env << EOF
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}
NODE_ENV=production
PORT=5000
EOF

echo "Loading environment variables..."
export $(cat .env | xargs)

echo "Installing dependencies..."
npm install

echo "Setting up database schema..."
npm run db:push

echo "Seeding database with initial data..."
npm run db:seed

echo "✅ Setup complete!"
echo ""
echo "Database: ${DB_NAME}"
echo "User: ${DB_USER}"
echo "Password: ${DB_PASSWORD}"
echo ""
echo "To start the application:"
echo "export \$(cat .env | xargs) && npm start"
echo ""
echo "Default login credentials:"
echo "Admin: admin / admin123"
echo "Demo: demo / demo123"